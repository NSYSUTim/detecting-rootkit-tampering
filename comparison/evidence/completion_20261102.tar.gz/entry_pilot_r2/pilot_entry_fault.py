import json,os,sys,subprocess
from pathlib import Path
sys.path[:0]=['.','src']
from finalization.tracefs_measurement import new_measurement,CompleteMeasurement
out=Path('fault_pilot.json');rows=[]
module=Path('../fault_module/kicba_entry_fault.ko').resolve()
subprocess.run(['insmod',str(module)],check=True)
try:
 with new_measurement(probe='/home/kicba/research_phase2_20261023/phase1/bin/d9_enum_probe') as base:
  tool=CompleteMeasurement(base);rows.append(tool.scan('fixture'))
  original=base.scan
  def inject(*args,**kwargs):
   Path('/sys/module/kicba_entry_fault/parameters/trigger').write_text('10\n')
   return original(*args,**kwargs)
  base.scan=inject;rows.append(tool.scan('fixture'));base.scan=original;rows.append(tool.scan('fixture'))
 rows.append({'injected':Path('/sys/module/kicba_entry_fault/parameters/injected').read_text().strip()})
finally:subprocess.run(['rmmod','kicba_entry_fault'],check=True)
out.write_text(json.dumps(rows,indent=2))
print([{k:v for k,v in row.items() if k in ('verdict','pre_entry_gate_verdict','entry_coverage','injected')} for row in rows])
