import os,sys,subprocess,json
from pathlib import Path
sys.path[:0]=['.','src']
from finalization import controlled_cases as c
root=Path('../private_fixture_pilot').resolve();root.mkdir()
fixture=root/'fixture';fixture.mkdir()
for name in c.NAMES:(fixture/name).touch()
original=__import__('phase2.run_campaign',fromlist=['manifest']).manifest(fixture)
base=Path('/home/kicba/research_phase2_20261023');first=Path('/home/kicba/research_phase1_20261023')
c.load('getdents_hiding',base,first)
try:
 control=c.exact_capture(base/'phase1/bin/d9_enum_probe',fixture,4096,root/'control.jsonl');(root/'control.json').write_text(json.dumps(control))
 with (root/'stdout').open('x') as out,(root/'stderr').open('x') as err:
  env=dict(os.environ,PATH=str(fixture)+':'+os.environ['PATH'])
  p=subprocess.run(['timeout','-s','QUIT','-k','2','15',str(Path('comparison_boot_01/official/d9_enum_probe').resolve()),'--cells','hidden_file','--no-isolation','--json'],env=env,stdout=out,stderr=err)
 print('exit',p.returncode)
finally:c.unload('getdents_hiding',base,first)
print((root/'stdout').read_text()[:600]);print((root/'stderr').read_text()[:1600])
