import os,tarfile,hashlib,json
from pathlib import Path
root=Path('/home/kicba/closure_20261102');output=Path('/home/kicba/closure_20261102_bundle.tar.gz')
if output.exists():raise FileExistsError(output)
selected={'.json','.jsonl','.stdout','.stderr','.time','.log','.md','.py','.c','.inc','.ko','.zip'}
count=0
with tarfile.open(output,'w:gz') as tar:
 for directory,folders,files in os.walk(root,followlinks=False):
  folders[:]=[n for n in folders if not (Path(directory)/n).is_symlink()]
  for name in files:
   p=Path(directory)/name
   if not p.is_symlink() and (p.suffix in selected or name=='Makefile'):
    tar.add(p,arcname=p.relative_to(root).as_posix(),recursive=False);count+=1
output.chmod(0o644)
print(json.dumps({'files':count,'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}))
